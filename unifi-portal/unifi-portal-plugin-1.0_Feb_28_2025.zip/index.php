<?php /* Silence Is Golden... The Quieter you become the more you are able to hear. */
