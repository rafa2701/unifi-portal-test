<?php

namespace Sfx\UnifiPortal;

if (!defined('UNI_PLUGIN_PATH')) {
    exit;
}

require_once UNI_PLUGIN_SRC_PATH  . 'helpers/utils.php';
require_once UNI_PLUGIN_SRC_PATH  . 'helpers/functions.php';
