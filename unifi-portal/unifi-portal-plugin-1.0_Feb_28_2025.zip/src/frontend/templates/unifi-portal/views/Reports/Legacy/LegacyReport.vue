<template></template>

<script>
export default {
  name: "LegacyReport",

  setup() {
    return {};
  },
};
</script>
